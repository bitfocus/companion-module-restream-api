module.exports = function (self) {
	const variables = [
		{ variableId: 'stream_status', name: 'Stream Status (LIVE/OFFLINE)' },
		{ variableId: 'is_streaming', name: 'Is Stream Live (true/false)' },
		{ variableId: 'stream_ws_connected', name: 'Streaming Telemetry (WebSocket) Connected' },
		{ variableId: 'stream_fps', name: 'Stream FPS' },
		{ variableId: 'stream_bitrate', name: 'Stream Bitrate (kbps)' },
		{ variableId: 'stream_resolution', name: 'Stream Resolution' },
		{ variableId: 'stream_codec', name: 'Stream Video Codec' },
		{ variableId: 'stream_audio_codec', name: 'Stream Audio Codec' },
		{ variableId: 'stream_event_title', name: 'Current Event / Stream Title' },
	]

	const channels = Array.isArray(self.channels) ? self.channels : []
	const platforms = Array.isArray(self.platforms) ? self.platforms : []

	// Expose variables for each channel
	for (const chan of channels) {
		if (!chan || !chan.id) continue
		const platform = platforms.find((ptfrm) => ptfrm && ptfrm.id == chan.streamingPlatformId)
		const platformName = platform?.name || 'Channel'
		const labelPrefix = `${platformName} (${chan.displayName || chan.id})`

		variables.push({
			variableId: `channel_${chan.id}_name`,
			name: `${labelPrefix} Display Name`,
		})
		variables.push({
			variableId: `channel_${chan.id}_platform`,
			name: `${labelPrefix} Platform Name`,
		})
		variables.push({
			variableId: `channel_${chan.id}_active`,
			name: `${labelPrefix} Active Status`,
		})
		variables.push({
			variableId: `channel_${chan.id}_title`,
			name: `${labelPrefix} Stream Title`,
		})
		variables.push({
			variableId: `channel_${chan.id}_description`,
			name: `${labelPrefix} Stream Description`,
		})

		// Channel metadata variables (any extra custom fields)
		if (chan.meta && typeof chan.meta === 'object') {
			for (const metaKey of Object.keys(chan.meta)) {
				if (metaKey === 'title' || metaKey === 'description') continue
				variables.push({
					variableId: `channel_${chan.id}_${metaKey}`,
					name: `${labelPrefix} ${metaKey}`,
				})
			}
		}
	}

	self.setVariableDefinitions(variables)

	// Update Variable Values
	const values = {
		stream_status: self.streamData?.status || 'OFFLINE',
		is_streaming: self.streamData?.isStreaming ? 'true' : 'false',
		stream_ws_connected: self.streamMonitor?.isConnected ? 'true' : 'false',
		stream_fps: self.streamData?.fps !== undefined ? String(self.streamData.fps) : '0',
		stream_bitrate: self.streamData?.bitrate !== undefined ? String(self.streamData.bitrate) : '0',
		stream_resolution: self.streamData?.resolution || 'N/A',
		stream_codec: self.streamData?.videoCodec || 'N/A',
		stream_audio_codec: self.streamData?.audioCodec || 'N/A',
		stream_event_title: self.streamData?.eventTitle || '',
	}

	for (const chan of channels) {
		if (!chan || !chan.id) continue
		const platform = platforms.find((ptfrm) => ptfrm && ptfrm.id == chan.streamingPlatformId)
		values[`channel_${chan.id}_name`] = chan.displayName || ''
		values[`channel_${chan.id}_platform`] = platform?.name || ''
		values[`channel_${chan.id}_active`] = Boolean(chan.active ?? chan.enabled) ? 'true' : 'false'
		values[`channel_${chan.id}_title`] =
			chan.meta?.title !== undefined && chan.meta?.title !== null ? String(chan.meta.title) : ''
		values[`channel_${chan.id}_description`] =
			chan.meta?.description !== undefined && chan.meta?.description !== null ? String(chan.meta.description) : ''

		if (chan.meta && typeof chan.meta === 'object') {
			for (const [key, val] of Object.entries(chan.meta)) {
				values[`channel_${chan.id}_${key}`] = val !== undefined && val !== null ? String(val) : ''
			}
		}
	}

	self.setVariableValues(values)
}
